﻿namespace QuanLyCaPhe
{


    partial class QuanLyCaPheDataSet
    {
        partial class DanhThu_ReportDataTable
        {
        }

        partial class ChiTietHoaDon_ReportDataTable
        {
        }
    }
}
