﻿namespace QuanLyCaPhe
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAdmin));
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.dtpNgayKetThucHoaDon = new System.Windows.Forms.DateTimePicker();
            this.dtpNgayTaoHoaDon = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvDanhThu = new System.Windows.Forms.DataGridView();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtSFname = new System.Windows.Forms.TextBox();
            this.btnTimkimF = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txtGiaF = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.cmbDanhMucF = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtFID = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dgvThucAn = new System.Windows.Forms.DataGridView();
            this.MaThucAn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenMonAn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnLuuF = new System.Windows.Forms.Button();
            this.btnHuyF = new System.Windows.Forms.Button();
            this.btnXemF = new System.Windows.Forms.Button();
            this.btnSuaF = new System.Windows.Forms.Button();
            this.btnXoaF = new System.Windows.Forms.Button();
            this.btnThemF = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel19 = new System.Windows.Forms.Panel();
            this.txtTenDM = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.txtIDDM = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.btnLuuDM = new System.Windows.Forms.Button();
            this.btnXemDM = new System.Windows.Forms.Button();
            this.btnSuaDM = new System.Windows.Forms.Button();
            this.btnXoaDM = new System.Windows.Forms.Button();
            this.btnThemDM = new System.Windows.Forms.Button();
            this.dgvDanhMuc = new System.Windows.Forms.DataGridView();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel23 = new System.Windows.Forms.Panel();
            this.txtTrangThaiB = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.txtTenB = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.txtIDB = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.btnLuuB = new System.Windows.Forms.Button();
            this.btnXemB = new System.Windows.Forms.Button();
            this.btnSuaB = new System.Windows.Forms.Button();
            this.btnXoaB = new System.Windows.Forms.Button();
            this.btnThemB = new System.Windows.Forms.Button();
            this.dgvBanAn = new System.Windows.Forms.DataGridView();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txtMaNVTK = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.dgvTK = new System.Windows.Forms.DataGridView();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txtMauKhauTK = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.btnReloadTK = new System.Windows.Forms.Button();
            this.btnReNewTK = new System.Windows.Forms.Button();
            this.btnHuyTK = new System.Windows.Forms.Button();
            this.btnLuuTK = new System.Windows.Forms.Button();
            this.btnXoaTK = new System.Windows.Forms.Button();
            this.btnThemTK = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txtTenTK = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.btnChonAnh = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnReloadNV = new System.Windows.Forms.Button();
            this.btnHuyNV = new System.Windows.Forms.Button();
            this.btnLuuNV = new System.Windows.Forms.Button();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Anh = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbChiTiet = new System.Windows.Forms.GroupBox();
            this.dtbNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.dtbNgayNV = new System.Windows.Forms.DateTimePicker();
            this.rdbNu = new System.Windows.Forms.RadioButton();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtTenNV = new System.Windows.Forms.TextBox();
            this.txtHoNV = new System.Windows.Forms.TextBox();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.btnRestart = new System.Windows.Forms.Button();
            this.btnBoChamCong = new System.Windows.Forms.Button();
            this.panel28 = new System.Windows.Forms.Panel();
            this.dtpTimeOut = new System.Windows.Forms.DateTimePicker();
            this.label23 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.txtMaNVCC = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnChamCong = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.label24 = new System.Windows.Forms.Label();
            this.dgvChamCong = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel27 = new System.Windows.Forms.Panel();
            this.dtpTimein = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txtTenNVCC = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.panel32 = new System.Windows.Forms.Panel();
            this.dgvTinhLuong = new System.Windows.Forms.DataGridView();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.btnReStartL = new System.Windows.Forms.Button();
            this.btnTinhLuong = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.Lươn = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.nrdTangCa = new System.Windows.Forms.NumericUpDown();
            this.txtThuong = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.txtMaNVL = new System.Windows.Forms.TextBox();
            this.txtTenL = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.QuanLyCaPheDataSet = new QuanLyCaPhe.QuanLyCaPheDataSet();
            this.DanhThu_ReportBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DanhThu_ReportTableAdapter = new QuanLyCaPhe.QuanLyCaPheDataSetTableAdapters.DanhThu_ReportTableAdapter();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhThu)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThucAn)).BeginInit();
            this.panel4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMuc)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBanAn)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTK)).BeginInit();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.gbChiTiet.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel29.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChamCong)).BeginInit();
            this.panel27.SuspendLayout();
            this.panel24.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.panel32.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTinhLuong)).BeginInit();
            this.panel31.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel34.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nrdTangCa)).BeginInit();
            this.panel33.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.QuanLyCaPheDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DanhThu_ReportBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Controls.Add(this.tabPage5);
            this.tabControl.Controls.Add(this.tabPage6);
            this.tabControl.Controls.Add(this.tabPage7);
            this.tabControl.Controls.Add(this.tabPage8);
            this.tabControl.Controls.Add(this.tabPage9);
            this.tabControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl.Location = new System.Drawing.Point(5, 1);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1022, 480);
            this.tabControl.TabIndex = 0;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1014, 447);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Danh Thu";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Purple;
            this.panel2.Controls.Add(this.btnThongKe);
            this.panel2.Controls.Add(this.dtpNgayKetThucHoaDon);
            this.panel2.Controls.Add(this.dtpNgayTaoHoaDon);
            this.panel2.Location = new System.Drawing.Point(2, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(694, 30);
            this.panel2.TabIndex = 1;
            // 
            // btnThongKe
            // 
            this.btnThongKe.BackColor = System.Drawing.Color.Yellow;
            this.btnThongKe.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKe.Location = new System.Drawing.Point(286, 4);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(102, 25);
            this.btnThongKe.TabIndex = 2;
            this.btnThongKe.Text = "Thống Kê";
            this.btnThongKe.UseVisualStyleBackColor = false;
            this.btnThongKe.Click += new System.EventHandler(this.btnThongKe_Click);
            // 
            // dtpNgayKetThucHoaDon
            // 
            this.dtpNgayKetThucHoaDon.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dtpNgayKetThucHoaDon.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dtpNgayKetThucHoaDon.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgayKetThucHoaDon.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayKetThucHoaDon.Location = new System.Drawing.Point(518, 3);
            this.dtpNgayKetThucHoaDon.Name = "dtpNgayKetThucHoaDon";
            this.dtpNgayKetThucHoaDon.Size = new System.Drawing.Size(174, 26);
            this.dtpNgayKetThucHoaDon.TabIndex = 1;
            // 
            // dtpNgayTaoHoaDon
            // 
            this.dtpNgayTaoHoaDon.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgayTaoHoaDon.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayTaoHoaDon.Location = new System.Drawing.Point(2, 3);
            this.dtpNgayTaoHoaDon.Name = "dtpNgayTaoHoaDon";
            this.dtpNgayTaoHoaDon.Size = new System.Drawing.Size(174, 26);
            this.dtpNgayTaoHoaDon.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvDanhThu);
            this.panel1.Location = new System.Drawing.Point(3, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(851, 417);
            this.panel1.TabIndex = 0;
            // 
            // dgvDanhThu
            // 
            this.dgvDanhThu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhThu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15});
            this.dgvDanhThu.Location = new System.Drawing.Point(2, 1);
            this.dgvDanhThu.Name = "dgvDanhThu";
            this.dgvDanhThu.Size = new System.Drawing.Size(846, 413);
            this.dgvDanhThu.TabIndex = 0;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "IDHoaDon";
            this.Column10.HeaderText = "ID Hoá Đơn";
            this.Column10.Name = "Column10";
            this.Column10.Width = 200;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "TenBan";
            this.Column11.HeaderText = "Tên Bàn";
            this.Column11.Name = "Column11";
            this.Column11.Width = 200;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "NgayTaoHoaDon";
            this.Column12.HeaderText = "Ngày Tạo Hóa Đơn";
            this.Column12.Name = "Column12";
            this.Column12.Width = 200;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "NgayKetThucHoaDon";
            this.Column13.HeaderText = "Ngày Kết Thúc Hóa Đơn";
            this.Column13.Name = "Column13";
            this.Column13.Width = 200;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "GiamGia";
            this.Column14.HeaderText = "Giảm Giá";
            this.Column14.Name = "Column14";
            this.Column14.Width = 200;
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "TongTien";
            this.Column15.HeaderText = "Tổng Tiền";
            this.Column15.Name = "Column15";
            this.Column15.Width = 250;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1014, 447);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Thức Ăn";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(2, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(995, 438);
            this.panel3.TabIndex = 0;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Yellow;
            this.panel7.Controls.Add(this.txtSFname);
            this.panel7.Controls.Add(this.btnTimkimF);
            this.panel7.Location = new System.Drawing.Point(651, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(341, 68);
            this.panel7.TabIndex = 3;
            // 
            // txtSFname
            // 
            this.txtSFname.Location = new System.Drawing.Point(160, 20);
            this.txtSFname.Name = "txtSFname";
            this.txtSFname.Size = new System.Drawing.Size(168, 26);
            this.txtSFname.TabIndex = 5;
            // 
            // btnTimkimF
            // 
            this.btnTimkimF.BackColor = System.Drawing.Color.Red;
            this.btnTimkimF.Location = new System.Drawing.Point(3, 3);
            this.btnTimkimF.Name = "btnTimkimF";
            this.btnTimkimF.Size = new System.Drawing.Size(145, 61);
            this.btnTimkimF.TabIndex = 4;
            this.btnTimkimF.Text = "Tìm";
            this.btnTimkimF.UseVisualStyleBackColor = false;
            this.btnTimkimF.Click += new System.EventHandler(this.btnTimkimF_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Yellow;
            this.panel6.Controls.Add(this.panel11);
            this.panel6.Controls.Add(this.panel10);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Location = new System.Drawing.Point(650, 77);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(345, 358);
            this.panel6.TabIndex = 2;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.Controls.Add(this.txtGiaF);
            this.panel11.Controls.Add(this.label3);
            this.panel11.Location = new System.Drawing.Point(0, 230);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(344, 39);
            this.panel11.TabIndex = 4;
            // 
            // txtGiaF
            // 
            this.txtGiaF.Location = new System.Drawing.Point(135, 6);
            this.txtGiaF.Name = "txtGiaF";
            this.txtGiaF.Size = new System.Drawing.Size(207, 26);
            this.txtGiaF.TabIndex = 1;
            this.txtGiaF.TextChanged += new System.EventHandler(this.txtFName_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Yellow;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "Giá :";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.Controls.Add(this.cmbDanhMucF);
            this.panel10.Controls.Add(this.label2);
            this.panel10.Location = new System.Drawing.Point(0, 168);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(345, 39);
            this.panel10.TabIndex = 3;
            // 
            // cmbDanhMucF
            // 
            this.cmbDanhMucF.FormattingEnabled = true;
            this.cmbDanhMucF.Location = new System.Drawing.Point(136, 8);
            this.cmbDanhMucF.Name = "cmbDanhMucF";
            this.cmbDanhMucF.Size = new System.Drawing.Size(206, 28);
            this.cmbDanhMucF.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Yellow;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Danh Mục:";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.Controls.Add(this.txtFName);
            this.panel9.Controls.Add(this.label1);
            this.panel9.Location = new System.Drawing.Point(1, 94);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(342, 39);
            this.panel9.TabIndex = 2;
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(131, 6);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(207, 26);
            this.txtFName.TabIndex = 1;
            this.txtFName.TextChanged += new System.EventHandler(this.txtFName_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Yellow;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(2, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tên Món :";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Controls.Add(this.txtFID);
            this.panel8.Controls.Add(this.label10);
            this.panel8.Location = new System.Drawing.Point(0, 12);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(344, 39);
            this.panel8.TabIndex = 1;
            // 
            // txtFID
            // 
            this.txtFID.Location = new System.Drawing.Point(131, 7);
            this.txtFID.Name = "txtFID";
            this.txtFID.ReadOnly = true;
            this.txtFID.Size = new System.Drawing.Size(207, 26);
            this.txtFID.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Yellow;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(35, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 25);
            this.label10.TabIndex = 0;
            this.label10.Text = "ID :";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dgvThucAn);
            this.panel5.Location = new System.Drawing.Point(147, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(498, 437);
            this.panel5.TabIndex = 1;
            // 
            // dgvThucAn
            // 
            this.dgvThucAn.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.dgvThucAn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThucAn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaThucAn,
            this.TenMonAn,
            this.Column9,
            this.Gia});
            this.dgvThucAn.Location = new System.Drawing.Point(0, 3);
            this.dgvThucAn.Name = "dgvThucAn";
            this.dgvThucAn.Size = new System.Drawing.Size(497, 435);
            this.dgvThucAn.TabIndex = 0;
            this.dgvThucAn.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvThucAn_CellClick);
            // 
            // MaThucAn
            // 
            this.MaThucAn.DataPropertyName = "IDThucAn";
            this.MaThucAn.HeaderText = "Mã Thức Ăn";
            this.MaThucAn.Name = "MaThucAn";
            this.MaThucAn.Width = 50;
            // 
            // TenMonAn
            // 
            this.TenMonAn.DataPropertyName = "TenThucAn";
            this.TenMonAn.HeaderText = "Tên Món Ăn";
            this.TenMonAn.Name = "TenMonAn";
            this.TenMonAn.Width = 200;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "IDLoaiThucAn";
            this.Column9.HeaderText = "Loại Món Ăn";
            this.Column9.Name = "Column9";
            // 
            // Gia
            // 
            this.Gia.DataPropertyName = "Gia";
            this.Gia.HeaderText = "Giá";
            this.Gia.Name = "Gia";
            this.Gia.Width = 105;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Yellow;
            this.panel4.Controls.Add(this.btnLuuF);
            this.panel4.Controls.Add(this.btnHuyF);
            this.panel4.Controls.Add(this.btnXemF);
            this.panel4.Controls.Add(this.btnSuaF);
            this.panel4.Controls.Add(this.btnXoaF);
            this.panel4.Controls.Add(this.btnThemF);
            this.panel4.Location = new System.Drawing.Point(4, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(144, 432);
            this.panel4.TabIndex = 0;
            // 
            // btnLuuF
            // 
            this.btnLuuF.BackColor = System.Drawing.Color.Cyan;
            this.btnLuuF.Location = new System.Drawing.Point(-1, 304);
            this.btnLuuF.Name = "btnLuuF";
            this.btnLuuF.Size = new System.Drawing.Size(145, 61);
            this.btnLuuF.TabIndex = 3;
            this.btnLuuF.Text = "Lưu";
            this.btnLuuF.UseVisualStyleBackColor = false;
            this.btnLuuF.Click += new System.EventHandler(this.btnLuuF_Click);
            // 
            // btnHuyF
            // 
            this.btnHuyF.BackColor = System.Drawing.Color.Cyan;
            this.btnHuyF.Location = new System.Drawing.Point(-1, 371);
            this.btnHuyF.Name = "btnHuyF";
            this.btnHuyF.Size = new System.Drawing.Size(145, 61);
            this.btnHuyF.TabIndex = 3;
            this.btnHuyF.Text = "Hủy";
            this.btnHuyF.UseVisualStyleBackColor = false;
            this.btnHuyF.Click += new System.EventHandler(this.btnHuyF_Click);
            // 
            // btnXemF
            // 
            this.btnXemF.BackColor = System.Drawing.Color.Cyan;
            this.btnXemF.Location = new System.Drawing.Point(-1, 220);
            this.btnXemF.Name = "btnXemF";
            this.btnXemF.Size = new System.Drawing.Size(145, 61);
            this.btnXemF.TabIndex = 3;
            this.btnXemF.Text = "Xem";
            this.btnXemF.UseVisualStyleBackColor = false;
            this.btnXemF.Click += new System.EventHandler(this.btnXemF_Click);
            // 
            // btnSuaF
            // 
            this.btnSuaF.BackColor = System.Drawing.Color.Red;
            this.btnSuaF.Location = new System.Drawing.Point(0, 146);
            this.btnSuaF.Name = "btnSuaF";
            this.btnSuaF.Size = new System.Drawing.Size(145, 61);
            this.btnSuaF.TabIndex = 2;
            this.btnSuaF.Text = "Sửa";
            this.btnSuaF.UseVisualStyleBackColor = false;
            this.btnSuaF.Click += new System.EventHandler(this.btnSuaF_Click);
            // 
            // btnXoaF
            // 
            this.btnXoaF.BackColor = System.Drawing.Color.Red;
            this.btnXoaF.Location = new System.Drawing.Point(0, 74);
            this.btnXoaF.Name = "btnXoaF";
            this.btnXoaF.Size = new System.Drawing.Size(145, 61);
            this.btnXoaF.TabIndex = 1;
            this.btnXoaF.Text = "Xóa";
            this.btnXoaF.UseVisualStyleBackColor = false;
            this.btnXoaF.Click += new System.EventHandler(this.btnXoaF_Click);
            // 
            // btnThemF
            // 
            this.btnThemF.BackColor = System.Drawing.Color.Red;
            this.btnThemF.Location = new System.Drawing.Point(-1, -3);
            this.btnThemF.Name = "btnThemF";
            this.btnThemF.Size = new System.Drawing.Size(145, 61);
            this.btnThemF.TabIndex = 0;
            this.btnThemF.Text = "Thêm";
            this.btnThemF.UseVisualStyleBackColor = false;
            this.btnThemF.Click += new System.EventHandler(this.btnThemF_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel19);
            this.tabPage3.Controls.Add(this.panel18);
            this.tabPage3.Controls.Add(this.panel17);
            this.tabPage3.Controls.Add(this.dgvDanhMuc);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1014, 447);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Danh Mục";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.txtTenDM);
            this.panel19.Controls.Add(this.label15);
            this.panel19.Location = new System.Drawing.Point(577, 9);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(391, 39);
            this.panel19.TabIndex = 4;
            // 
            // txtTenDM
            // 
            this.txtTenDM.Location = new System.Drawing.Point(181, 8);
            this.txtTenDM.Name = "txtTenDM";
            this.txtTenDM.Size = new System.Drawing.Size(207, 26);
            this.txtTenDM.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(3, 6);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(179, 25);
            this.label15.TabIndex = 0;
            this.label15.Text = "Tên Danh Mục :";
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.txtIDDM);
            this.panel18.Controls.Add(this.label8);
            this.panel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel18.Location = new System.Drawing.Point(285, 9);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(292, 39);
            this.panel18.TabIndex = 3;
            // 
            // txtIDDM
            // 
            this.txtIDDM.Location = new System.Drawing.Point(83, 8);
            this.txtIDDM.Name = "txtIDDM";
            this.txtIDDM.ReadOnly = true;
            this.txtIDDM.Size = new System.Drawing.Size(207, 26);
            this.txtIDDM.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(13, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 25);
            this.label8.TabIndex = 0;
            this.label8.Text = "ID :";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Yellow;
            this.panel17.Controls.Add(this.btnLuuDM);
            this.panel17.Controls.Add(this.btnXemDM);
            this.panel17.Controls.Add(this.btnSuaDM);
            this.panel17.Controls.Add(this.btnXoaDM);
            this.panel17.Controls.Add(this.btnThemDM);
            this.panel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel17.Location = new System.Drawing.Point(89, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(148, 441);
            this.panel17.TabIndex = 2;
            // 
            // btnLuuDM
            // 
            this.btnLuuDM.BackColor = System.Drawing.Color.Red;
            this.btnLuuDM.Location = new System.Drawing.Point(1, 368);
            this.btnLuuDM.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnLuuDM.Name = "btnLuuDM";
            this.btnLuuDM.Size = new System.Drawing.Size(145, 61);
            this.btnLuuDM.TabIndex = 4;
            this.btnLuuDM.Text = "Lưu";
            this.btnLuuDM.UseVisualStyleBackColor = false;
            this.btnLuuDM.Click += new System.EventHandler(this.btnLuuDM_Click);
            // 
            // btnXemDM
            // 
            this.btnXemDM.BackColor = System.Drawing.Color.Cyan;
            this.btnXemDM.Location = new System.Drawing.Point(1, 281);
            this.btnXemDM.Name = "btnXemDM";
            this.btnXemDM.Size = new System.Drawing.Size(145, 61);
            this.btnXemDM.TabIndex = 3;
            this.btnXemDM.Text = "Xem";
            this.btnXemDM.UseVisualStyleBackColor = false;
            this.btnXemDM.Click += new System.EventHandler(this.btnXemDM_Click);
            // 
            // btnSuaDM
            // 
            this.btnSuaDM.BackColor = System.Drawing.Color.Red;
            this.btnSuaDM.Location = new System.Drawing.Point(0, 195);
            this.btnSuaDM.Name = "btnSuaDM";
            this.btnSuaDM.Size = new System.Drawing.Size(145, 61);
            this.btnSuaDM.TabIndex = 2;
            this.btnSuaDM.Text = "Sửa";
            this.btnSuaDM.UseVisualStyleBackColor = false;
            this.btnSuaDM.Click += new System.EventHandler(this.btnSuaDM_Click);
            // 
            // btnXoaDM
            // 
            this.btnXoaDM.BackColor = System.Drawing.Color.Red;
            this.btnXoaDM.Location = new System.Drawing.Point(0, 104);
            this.btnXoaDM.Name = "btnXoaDM";
            this.btnXoaDM.Size = new System.Drawing.Size(145, 61);
            this.btnXoaDM.TabIndex = 1;
            this.btnXoaDM.Text = "Xóa";
            this.btnXoaDM.UseVisualStyleBackColor = false;
            this.btnXoaDM.Click += new System.EventHandler(this.btnXoaDM_Click);
            // 
            // btnThemDM
            // 
            this.btnThemDM.BackColor = System.Drawing.Color.Red;
            this.btnThemDM.Location = new System.Drawing.Point(0, 19);
            this.btnThemDM.Name = "btnThemDM";
            this.btnThemDM.Size = new System.Drawing.Size(145, 61);
            this.btnThemDM.TabIndex = 0;
            this.btnThemDM.Text = "Thêm";
            this.btnThemDM.UseVisualStyleBackColor = false;
            this.btnThemDM.Click += new System.EventHandler(this.btnThemDM_Click);
            // 
            // dgvDanhMuc
            // 
            this.dgvDanhMuc.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.dgvDanhMuc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhMuc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column21,
            this.Column22});
            this.dgvDanhMuc.Location = new System.Drawing.Point(336, 54);
            this.dgvDanhMuc.Name = "dgvDanhMuc";
            this.dgvDanhMuc.Size = new System.Drawing.Size(544, 391);
            this.dgvDanhMuc.TabIndex = 1;
            this.dgvDanhMuc.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDanhMuc_CellClick);
            // 
            // Column21
            // 
            this.Column21.DataPropertyName = "IDLoaiThucAn";
            this.Column21.HeaderText = "ID Loại Thức Ăn";
            this.Column21.Name = "Column21";
            this.Column21.Width = 200;
            // 
            // Column22
            // 
            this.Column22.DataPropertyName = "TenLoaiThucAn";
            this.Column22.HeaderText = "Tên Loại thức Ăn";
            this.Column22.Name = "Column22";
            this.Column22.Width = 300;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel23);
            this.tabPage4.Controls.Add(this.panel22);
            this.tabPage4.Controls.Add(this.panel21);
            this.tabPage4.Controls.Add(this.panel20);
            this.tabPage4.Controls.Add(this.dgvBanAn);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1014, 447);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Bàn Ăn";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.txtTrangThaiB);
            this.panel23.Controls.Add(this.label18);
            this.panel23.Location = new System.Drawing.Point(665, 180);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(342, 39);
            this.panel23.TabIndex = 6;
            // 
            // txtTrangThaiB
            // 
            this.txtTrangThaiB.Location = new System.Drawing.Point(134, 6);
            this.txtTrangThaiB.Name = "txtTrangThaiB";
            this.txtTrangThaiB.Size = new System.Drawing.Size(207, 26);
            this.txtTrangThaiB.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(3, 6);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(140, 25);
            this.label18.TabIndex = 0;
            this.label18.Text = "Trạng Thái :";
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.txtTenB);
            this.panel22.Controls.Add(this.label17);
            this.panel22.Location = new System.Drawing.Point(661, 74);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(342, 39);
            this.panel22.TabIndex = 5;
            // 
            // txtTenB
            // 
            this.txtTenB.Location = new System.Drawing.Point(134, 6);
            this.txtTenB.Name = "txtTenB";
            this.txtTenB.Size = new System.Drawing.Size(207, 26);
            this.txtTenB.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(3, 6);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(149, 25);
            this.label17.TabIndex = 0;
            this.label17.Text = "Tên Bàn Ăn :";
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.txtIDB);
            this.panel21.Controls.Add(this.label16);
            this.panel21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel21.Location = new System.Drawing.Point(663, 277);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(344, 39);
            this.panel21.TabIndex = 4;
            // 
            // txtIDB
            // 
            this.txtIDB.Location = new System.Drawing.Point(134, 8);
            this.txtIDB.Name = "txtIDB";
            this.txtIDB.ReadOnly = true;
            this.txtIDB.Size = new System.Drawing.Size(207, 26);
            this.txtIDB.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(60, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 25);
            this.label16.TabIndex = 0;
            this.label16.Text = "ID :";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Yellow;
            this.panel20.Controls.Add(this.btnLuuB);
            this.panel20.Controls.Add(this.btnXemB);
            this.panel20.Controls.Add(this.btnSuaB);
            this.panel20.Controls.Add(this.btnXoaB);
            this.panel20.Controls.Add(this.btnThemB);
            this.panel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel20.Location = new System.Drawing.Point(3, 3);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(151, 441);
            this.panel20.TabIndex = 3;
            // 
            // btnLuuB
            // 
            this.btnLuuB.BackColor = System.Drawing.Color.Red;
            this.btnLuuB.Location = new System.Drawing.Point(3, 377);
            this.btnLuuB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnLuuB.Name = "btnLuuB";
            this.btnLuuB.Size = new System.Drawing.Size(145, 61);
            this.btnLuuB.TabIndex = 5;
            this.btnLuuB.Text = "Lưu";
            this.btnLuuB.UseVisualStyleBackColor = false;
            this.btnLuuB.Click += new System.EventHandler(this.btnLuuB_Click);
            // 
            // btnXemB
            // 
            this.btnXemB.BackColor = System.Drawing.Color.Cyan;
            this.btnXemB.Location = new System.Drawing.Point(3, 284);
            this.btnXemB.Name = "btnXemB";
            this.btnXemB.Size = new System.Drawing.Size(145, 61);
            this.btnXemB.TabIndex = 3;
            this.btnXemB.Text = "Xem";
            this.btnXemB.UseVisualStyleBackColor = false;
            this.btnXemB.Click += new System.EventHandler(this.btnXemB_Click);
            // 
            // btnSuaB
            // 
            this.btnSuaB.BackColor = System.Drawing.Color.Red;
            this.btnSuaB.Location = new System.Drawing.Point(3, 195);
            this.btnSuaB.Name = "btnSuaB";
            this.btnSuaB.Size = new System.Drawing.Size(145, 61);
            this.btnSuaB.TabIndex = 2;
            this.btnSuaB.Text = "Sửa";
            this.btnSuaB.UseVisualStyleBackColor = false;
            this.btnSuaB.Click += new System.EventHandler(this.btnSuaB_Click);
            // 
            // btnXoaB
            // 
            this.btnXoaB.BackColor = System.Drawing.Color.Red;
            this.btnXoaB.Location = new System.Drawing.Point(3, 93);
            this.btnXoaB.Name = "btnXoaB";
            this.btnXoaB.Size = new System.Drawing.Size(145, 61);
            this.btnXoaB.TabIndex = 1;
            this.btnXoaB.Text = "Xóa";
            this.btnXoaB.UseVisualStyleBackColor = false;
            this.btnXoaB.Click += new System.EventHandler(this.btnXoaB_Click);
            // 
            // btnThemB
            // 
            this.btnThemB.BackColor = System.Drawing.Color.Red;
            this.btnThemB.Location = new System.Drawing.Point(3, 0);
            this.btnThemB.Name = "btnThemB";
            this.btnThemB.Size = new System.Drawing.Size(145, 61);
            this.btnThemB.TabIndex = 0;
            this.btnThemB.Text = "Thêm";
            this.btnThemB.UseVisualStyleBackColor = false;
            this.btnThemB.Click += new System.EventHandler(this.btnThemB_Click);
            // 
            // dgvBanAn
            // 
            this.dgvBanAn.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.dgvBanAn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBanAn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column23,
            this.Column24,
            this.Column25});
            this.dgvBanAn.Location = new System.Drawing.Point(160, 3);
            this.dgvBanAn.Name = "dgvBanAn";
            this.dgvBanAn.Size = new System.Drawing.Size(495, 435);
            this.dgvBanAn.TabIndex = 2;
            this.dgvBanAn.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBanAn_CellClick);
            // 
            // Column23
            // 
            this.Column23.DataPropertyName = "IDBanAn";
            this.Column23.HeaderText = "ID Bàn Ăn";
            this.Column23.Name = "Column23";
            this.Column23.Width = 150;
            // 
            // Column24
            // 
            this.Column24.DataPropertyName = "TenBan";
            this.Column24.HeaderText = "Tên Bàn";
            this.Column24.Name = "Column24";
            this.Column24.Width = 150;
            // 
            // Column25
            // 
            this.Column25.DataPropertyName = "TinhTrang";
            this.Column25.HeaderText = "Tình Trạng";
            this.Column25.Name = "Column25";
            this.Column25.Width = 150;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel16);
            this.tabPage5.Controls.Add(this.dgvTK);
            this.tabPage5.Controls.Add(this.panel15);
            this.tabPage5.Controls.Add(this.panel14);
            this.tabPage5.Controls.Add(this.panel13);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1014, 447);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Tài Khoản";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel16.Controls.Add(this.txtMaNVTK);
            this.panel16.Controls.Add(this.label19);
            this.panel16.Location = new System.Drawing.Point(731, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(280, 44);
            this.panel16.TabIndex = 7;
            // 
            // txtMaNVTK
            // 
            this.txtMaNVTK.Location = new System.Drawing.Point(81, 6);
            this.txtMaNVTK.Name = "txtMaNVTK";
            this.txtMaNVTK.Size = new System.Drawing.Size(191, 26);
            this.txtMaNVTK.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 9);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 20);
            this.label19.TabIndex = 0;
            this.label19.Text = "Mã NV :";
            // 
            // dgvTK
            // 
            this.dgvTK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTK.Location = new System.Drawing.Point(192, 53);
            this.dgvTK.Name = "dgvTK";
            this.dgvTK.Size = new System.Drawing.Size(614, 289);
            this.dgvTK.TabIndex = 0;
            this.dgvTK.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTK_CellClick);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel15.Controls.Add(this.txtMauKhauTK);
            this.panel15.Controls.Add(this.label5);
            this.panel15.Location = new System.Drawing.Point(344, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(384, 44);
            this.panel15.TabIndex = 3;
            // 
            // txtMauKhauTK
            // 
            this.txtMauKhauTK.Location = new System.Drawing.Point(94, 9);
            this.txtMauKhauTK.Name = "txtMauKhauTK";
            this.txtMauKhauTK.Size = new System.Drawing.Size(278, 26);
            this.txtMauKhauTK.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Mật Khẩu :";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel14.Controls.Add(this.btnReloadTK);
            this.panel14.Controls.Add(this.btnReNewTK);
            this.panel14.Controls.Add(this.btnHuyTK);
            this.panel14.Controls.Add(this.btnLuuTK);
            this.panel14.Controls.Add(this.btnXoaTK);
            this.panel14.Controls.Add(this.btnThemTK);
            this.panel14.Location = new System.Drawing.Point(156, 367);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(691, 56);
            this.panel14.TabIndex = 2;
            // 
            // btnReloadTK
            // 
            this.btnReloadTK.BackColor = System.Drawing.Color.Cyan;
            this.btnReloadTK.Location = new System.Drawing.Point(602, 4);
            this.btnReloadTK.Name = "btnReloadTK";
            this.btnReloadTK.Size = new System.Drawing.Size(86, 52);
            this.btnReloadTK.TabIndex = 5;
            this.btnReloadTK.Text = "ReLoad";
            this.btnReloadTK.UseVisualStyleBackColor = false;
            this.btnReloadTK.Click += new System.EventHandler(this.btnReloadTK_Click);
            // 
            // btnReNewTK
            // 
            this.btnReNewTK.BackColor = System.Drawing.Color.Cyan;
            this.btnReNewTK.Location = new System.Drawing.Point(510, 4);
            this.btnReNewTK.Name = "btnReNewTK";
            this.btnReNewTK.Size = new System.Drawing.Size(86, 52);
            this.btnReNewTK.TabIndex = 4;
            this.btnReNewTK.Text = "ReNew Pass";
            this.btnReNewTK.UseVisualStyleBackColor = false;
            this.btnReNewTK.Click += new System.EventHandler(this.btnReNewTK_Click);
            // 
            // btnHuyTK
            // 
            this.btnHuyTK.BackColor = System.Drawing.Color.Silver;
            this.btnHuyTK.Location = new System.Drawing.Point(347, 3);
            this.btnHuyTK.Name = "btnHuyTK";
            this.btnHuyTK.Size = new System.Drawing.Size(86, 52);
            this.btnHuyTK.TabIndex = 3;
            this.btnHuyTK.Text = "Hủy";
            this.btnHuyTK.UseVisualStyleBackColor = false;
            this.btnHuyTK.Click += new System.EventHandler(this.btnHuyTK_Click);
            // 
            // btnLuuTK
            // 
            this.btnLuuTK.BackColor = System.Drawing.Color.Silver;
            this.btnLuuTK.Location = new System.Drawing.Point(255, 4);
            this.btnLuuTK.Name = "btnLuuTK";
            this.btnLuuTK.Size = new System.Drawing.Size(86, 52);
            this.btnLuuTK.TabIndex = 2;
            this.btnLuuTK.Text = "Lưu";
            this.btnLuuTK.UseVisualStyleBackColor = false;
            this.btnLuuTK.Click += new System.EventHandler(this.btnLuuTK_Click);
            // 
            // btnXoaTK
            // 
            this.btnXoaTK.BackColor = System.Drawing.Color.Lime;
            this.btnXoaTK.Location = new System.Drawing.Point(88, 3);
            this.btnXoaTK.Name = "btnXoaTK";
            this.btnXoaTK.Size = new System.Drawing.Size(86, 52);
            this.btnXoaTK.TabIndex = 1;
            this.btnXoaTK.Text = "Xóa";
            this.btnXoaTK.UseVisualStyleBackColor = false;
            this.btnXoaTK.Click += new System.EventHandler(this.btnXoaTK_Click);
            // 
            // btnThemTK
            // 
            this.btnThemTK.BackColor = System.Drawing.Color.Lime;
            this.btnThemTK.Location = new System.Drawing.Point(0, 3);
            this.btnThemTK.Name = "btnThemTK";
            this.btnThemTK.Size = new System.Drawing.Size(86, 52);
            this.btnThemTK.TabIndex = 0;
            this.btnThemTK.Text = "Thêm";
            this.btnThemTK.UseVisualStyleBackColor = false;
            this.btnThemTK.Click += new System.EventHandler(this.btnThemTK_Click);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel13.Controls.Add(this.txtTenTK);
            this.panel13.Controls.Add(this.label4);
            this.panel13.Location = new System.Drawing.Point(0, 3);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(340, 44);
            this.panel13.TabIndex = 1;
            // 
            // txtTenTK
            // 
            this.txtTenTK.Location = new System.Drawing.Point(144, 9);
            this.txtTenTK.Name = "txtTenTK";
            this.txtTenTK.Size = new System.Drawing.Size(191, 26);
            this.txtTenTK.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Tên Đăng Nhập :";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.btnChonAnh);
            this.tabPage6.Controls.Add(this.pictureBox1);
            this.tabPage6.Controls.Add(this.btnReloadNV);
            this.tabPage6.Controls.Add(this.btnHuyNV);
            this.tabPage6.Controls.Add(this.btnLuuNV);
            this.tabPage6.Controls.Add(this.btnXoaNV);
            this.tabPage6.Controls.Add(this.btnThemNV);
            this.tabPage6.Controls.Add(this.dgvNhanVien);
            this.tabPage6.Controls.Add(this.gbChiTiet);
            this.tabPage6.Location = new System.Drawing.Point(4, 29);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1014, 447);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Nhân Viên";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // btnChonAnh
            // 
            this.btnChonAnh.BackColor = System.Drawing.Color.Red;
            this.btnChonAnh.Location = new System.Drawing.Point(934, 8);
            this.btnChonAnh.Name = "btnChonAnh";
            this.btnChonAnh.Size = new System.Drawing.Size(74, 161);
            this.btnChonAnh.TabIndex = 26;
            this.btnChonAnh.Text = "Chọn Ảnh";
            this.btnChonAnh.UseVisualStyleBackColor = false;
            this.btnChonAnh.Click += new System.EventHandler(this.btnChonAnh_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(748, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(180, 158);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // btnReloadNV
            // 
            this.btnReloadNV.BackColor = System.Drawing.Color.Lime;
            this.btnReloadNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReloadNV.Location = new System.Drawing.Point(577, 114);
            this.btnReloadNV.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnReloadNV.Name = "btnReloadNV";
            this.btnReloadNV.Size = new System.Drawing.Size(166, 51);
            this.btnReloadNV.TabIndex = 21;
            this.btnReloadNV.Text = "ReLoad";
            this.btnReloadNV.UseVisualStyleBackColor = false;
            this.btnReloadNV.Click += new System.EventHandler(this.btnReloadNV_Click);
            // 
            // btnHuyNV
            // 
            this.btnHuyNV.BackColor = System.Drawing.Color.Red;
            this.btnHuyNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuyNV.Location = new System.Drawing.Point(662, 60);
            this.btnHuyNV.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnHuyNV.Name = "btnHuyNV";
            this.btnHuyNV.Size = new System.Drawing.Size(81, 51);
            this.btnHuyNV.TabIndex = 20;
            this.btnHuyNV.Text = "Hủy";
            this.btnHuyNV.UseVisualStyleBackColor = false;
            this.btnHuyNV.Click += new System.EventHandler(this.btnHuyNV_Click);
            // 
            // btnLuuNV
            // 
            this.btnLuuNV.BackColor = System.Drawing.Color.Red;
            this.btnLuuNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuNV.Location = new System.Drawing.Point(577, 55);
            this.btnLuuNV.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnLuuNV.Name = "btnLuuNV";
            this.btnLuuNV.Size = new System.Drawing.Size(81, 51);
            this.btnLuuNV.TabIndex = 19;
            this.btnLuuNV.Text = "Lưu";
            this.btnLuuNV.UseVisualStyleBackColor = false;
            this.btnLuuNV.Click += new System.EventHandler(this.btnLuuNV_Click);
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.BackColor = System.Drawing.Color.Yellow;
            this.btnXoaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaNV.Location = new System.Drawing.Point(662, 4);
            this.btnXoaNV.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(81, 51);
            this.btnXoaNV.TabIndex = 18;
            this.btnXoaNV.Text = "Xóa";
            this.btnXoaNV.UseVisualStyleBackColor = false;
            this.btnXoaNV.Click += new System.EventHandler(this.btnXoaNV_Click);
            // 
            // btnThemNV
            // 
            this.btnThemNV.BackColor = System.Drawing.Color.Yellow;
            this.btnThemNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemNV.Location = new System.Drawing.Point(577, 3);
            this.btnThemNV.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(81, 51);
            this.btnThemNV.TabIndex = 17;
            this.btnThemNV.Text = "Thêm";
            this.btnThemNV.UseVisualStyleBackColor = false;
            this.btnThemNV.Click += new System.EventHandler(this.btnThemNV_Click);
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Anh,
            this.Column4,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column5,
            this.column2,
            this.Column3});
            this.dgvNhanVien.Location = new System.Drawing.Point(0, 173);
            this.dgvNhanVien.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.Size = new System.Drawing.Size(1008, 269);
            this.dgvNhanVien.TabIndex = 0;
            this.dgvNhanVien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNhanVien_CellClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "MaNV";
            this.Column1.HeaderText = "ID NV";
            this.Column1.Name = "Column1";
            // 
            // Anh
            // 
            this.Anh.DataPropertyName = "HinhAnh";
            this.Anh.HeaderText = "Ảnh";
            this.Anh.Name = "Anh";
            this.Anh.Width = 160;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Nu";
            this.Column4.HeaderText = "Nữ";
            this.Column4.Name = "Column4";
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "SDT";
            this.Column6.HeaderText = "SDT";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "DiaChi";
            this.Column7.HeaderText = "Địa Chỉ";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "NgayBD";
            this.Column8.HeaderText = "Ngày NV";
            this.Column8.Name = "Column8";
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "NgaySinh";
            this.Column5.HeaderText = "Ngày Sinh";
            this.Column5.Name = "Column5";
            this.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // column2
            // 
            this.column2.DataPropertyName = "HoNV";
            this.column2.HeaderText = "Họ";
            this.column2.Name = "column2";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "TenNV";
            this.Column3.HeaderText = "Tên";
            this.Column3.Name = "Column3";
            // 
            // gbChiTiet
            // 
            this.gbChiTiet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.gbChiTiet.Controls.Add(this.dtbNgaySinh);
            this.gbChiTiet.Controls.Add(this.label9);
            this.gbChiTiet.Controls.Add(this.dtbNgayNV);
            this.gbChiTiet.Controls.Add(this.rdbNu);
            this.gbChiTiet.Controls.Add(this.txtDienThoai);
            this.gbChiTiet.Controls.Add(this.txtDiaChi);
            this.gbChiTiet.Controls.Add(this.txtTenNV);
            this.gbChiTiet.Controls.Add(this.txtHoNV);
            this.gbChiTiet.Controls.Add(this.txtMaNV);
            this.gbChiTiet.Controls.Add(this.label7);
            this.gbChiTiet.Controls.Add(this.label6);
            this.gbChiTiet.Controls.Add(this.label11);
            this.gbChiTiet.Controls.Add(this.label12);
            this.gbChiTiet.Controls.Add(this.label13);
            this.gbChiTiet.Controls.Add(this.label14);
            this.gbChiTiet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbChiTiet.Location = new System.Drawing.Point(2, 0);
            this.gbChiTiet.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.gbChiTiet.Name = "gbChiTiet";
            this.gbChiTiet.Padding = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.gbChiTiet.Size = new System.Drawing.Size(571, 169);
            this.gbChiTiet.TabIndex = 16;
            this.gbChiTiet.TabStop = false;
            this.gbChiTiet.Text = "Thông tin chi tiết";
            // 
            // dtbNgaySinh
            // 
            this.dtbNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtbNgaySinh.Location = new System.Drawing.Point(384, 131);
            this.dtbNgaySinh.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.dtbNgaySinh.Name = "dtbNgaySinh";
            this.dtbNgaySinh.Size = new System.Drawing.Size(133, 22);
            this.dtbNgaySinh.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(228, 138);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 16);
            this.label9.TabIndex = 15;
            this.label9.Text = "Ngày Sinh :";
            // 
            // dtbNgayNV
            // 
            this.dtbNgayNV.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtbNgayNV.Location = new System.Drawing.Point(384, 72);
            this.dtbNgayNV.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.dtbNgayNV.Name = "dtbNgayNV";
            this.dtbNgayNV.Size = new System.Drawing.Size(133, 22);
            this.dtbNgayNV.TabIndex = 14;
            // 
            // rdbNu
            // 
            this.rdbNu.AutoSize = true;
            this.rdbNu.Location = new System.Drawing.Point(231, 34);
            this.rdbNu.Name = "rdbNu";
            this.rdbNu.Size = new System.Drawing.Size(45, 20);
            this.rdbNu.TabIndex = 13;
            this.rdbNu.TabStop = true;
            this.rdbNu.Text = "Nữ";
            this.rdbNu.UseVisualStyleBackColor = true;
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Location = new System.Drawing.Point(384, 40);
            this.txtDienThoai.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(133, 22);
            this.txtDienThoai.TabIndex = 12;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(317, 100);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(200, 22);
            this.txtDiaChi.TabIndex = 11;
            // 
            // txtTenNV
            // 
            this.txtTenNV.Location = new System.Drawing.Point(91, 118);
            this.txtTenNV.Name = "txtTenNV";
            this.txtTenNV.Size = new System.Drawing.Size(115, 22);
            this.txtTenNV.TabIndex = 10;
            // 
            // txtHoNV
            // 
            this.txtHoNV.Location = new System.Drawing.Point(91, 74);
            this.txtHoNV.Name = "txtHoNV";
            this.txtHoNV.Size = new System.Drawing.Size(115, 22);
            this.txtHoNV.TabIndex = 9;
            // 
            // txtMaNV
            // 
            this.txtMaNV.Location = new System.Drawing.Point(136, 38);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(70, 22);
            this.txtMaNV.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(294, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "Điện Thoại :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(228, 74);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Ngày Nhận Việc :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(228, 105);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 16);
            this.label11.TabIndex = 5;
            this.label11.Text = "Địa Chỉ :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(28, 131);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 16);
            this.label12.TabIndex = 4;
            this.label12.Text = "Tên :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 72);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 16);
            this.label13.TabIndex = 3;
            this.label13.Text = "Họ : ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(4, 43);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 16);
            this.label14.TabIndex = 2;
            this.label14.Text = "Mã Nhân Viên :";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.btnRestart);
            this.tabPage7.Controls.Add(this.btnBoChamCong);
            this.tabPage7.Controls.Add(this.panel28);
            this.tabPage7.Controls.Add(this.panel26);
            this.tabPage7.Controls.Add(this.btnThoat);
            this.tabPage7.Controls.Add(this.btnChamCong);
            this.tabPage7.Controls.Add(this.panel29);
            this.tabPage7.Controls.Add(this.dgvChamCong);
            this.tabPage7.Controls.Add(this.panel27);
            this.tabPage7.Controls.Add(this.panel24);
            this.tabPage7.Location = new System.Drawing.Point(4, 29);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.tabPage7.Size = new System.Drawing.Size(1014, 447);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Chấm Công";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // btnRestart
            // 
            this.btnRestart.Location = new System.Drawing.Point(856, 390);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(155, 47);
            this.btnRestart.TabIndex = 18;
            this.btnRestart.Text = "ReStart";
            this.btnRestart.UseVisualStyleBackColor = true;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // btnBoChamCong
            // 
            this.btnBoChamCong.Location = new System.Drawing.Point(475, 389);
            this.btnBoChamCong.Name = "btnBoChamCong";
            this.btnBoChamCong.Size = new System.Drawing.Size(155, 47);
            this.btnBoChamCong.TabIndex = 11;
            this.btnBoChamCong.Text = "Bỏ Chấm Công";
            this.btnBoChamCong.UseVisualStyleBackColor = true;
            this.btnBoChamCong.Click += new System.EventHandler(this.btnBoChamCong_Click);
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.dtpTimeOut);
            this.panel28.Controls.Add(this.label23);
            this.panel28.Location = new System.Drawing.Point(635, 64);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(299, 40);
            this.panel28.TabIndex = 16;
            // 
            // dtpTimeOut
            // 
            this.dtpTimeOut.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpTimeOut.Location = new System.Drawing.Point(93, 6);
            this.dtpTimeOut.Name = "dtpTimeOut";
            this.dtpTimeOut.ShowCheckBox = true;
            this.dtpTimeOut.ShowUpDown = true;
            this.dtpTimeOut.Size = new System.Drawing.Size(194, 26);
            this.dtpTimeOut.TabIndex = 5;
            this.dtpTimeOut.Value = new System.DateTime(2019, 5, 16, 19, 14, 53, 0);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 12);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(75, 20);
            this.label23.TabIndex = 3;
            this.label23.Text = "Giờ Ra :";
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.txtMaNVCC);
            this.panel26.Controls.Add(this.label21);
            this.panel26.Location = new System.Drawing.Point(101, 64);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(299, 40);
            this.panel26.TabIndex = 14;
            // 
            // txtMaNVCC
            // 
            this.txtMaNVCC.Location = new System.Drawing.Point(87, 8);
            this.txtMaNVCC.Name = "txtMaNVCC";
            this.txtMaNVCC.Size = new System.Drawing.Size(198, 26);
            this.txtMaNVCC.TabIndex = 3;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 12);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(72, 20);
            this.label21.TabIndex = 3;
            this.label21.Text = "Mã NV :";
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(671, 389);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(155, 47);
            this.btnThoat.TabIndex = 12;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnChamCong
            // 
            this.btnChamCong.Location = new System.Drawing.Point(253, 390);
            this.btnChamCong.Name = "btnChamCong";
            this.btnChamCong.Size = new System.Drawing.Size(170, 47);
            this.btnChamCong.TabIndex = 9;
            this.btnChamCong.Text = "Chấm Công";
            this.btnChamCong.UseVisualStyleBackColor = true;
            this.btnChamCong.Click += new System.EventHandler(this.btnChamCong_Click);
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.dateTimePicker5);
            this.panel29.Controls.Add(this.label24);
            this.panel29.Location = new System.Drawing.Point(5, 390);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(221, 46);
            this.panel29.TabIndex = 17;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker5.Location = new System.Drawing.Point(75, 10);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(131, 26);
            this.dateTimePicker5.TabIndex = 1;
            this.dateTimePicker5.ValueChanged += new System.EventHandler(this.dateTimePicker5_ValueChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 13);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(59, 20);
            this.label24.TabIndex = 0;
            this.label24.Text = "Ngày :";
            // 
            // dgvChamCong
            // 
            this.dgvChamCong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChamCong.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.Column16});
            this.dgvChamCong.Location = new System.Drawing.Point(8, 121);
            this.dgvChamCong.Name = "dgvChamCong";
            this.dgvChamCong.Size = new System.Drawing.Size(999, 261);
            this.dgvChamCong.TabIndex = 10;
            this.dgvChamCong.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvChamCong_CellClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "MaNV";
            this.dataGridViewTextBoxColumn1.HeaderText = "Mã NV";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 230;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "TenNV";
            this.dataGridViewTextBoxColumn2.HeaderText = "Tên NV";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 250;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "GioIn";
            this.dataGridViewTextBoxColumn3.HeaderText = "Giờ Vào";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 240;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "GioOut";
            this.Column16.HeaderText = "Giờ Ra";
            this.Column16.Name = "Column16";
            this.Column16.Width = 240;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.dtpTimein);
            this.panel27.Controls.Add(this.label22);
            this.panel27.Location = new System.Drawing.Point(635, 17);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(299, 40);
            this.panel27.TabIndex = 15;
            // 
            // dtpTimein
            // 
            this.dtpTimein.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpTimein.Location = new System.Drawing.Point(93, 6);
            this.dtpTimein.Name = "dtpTimein";
            this.dtpTimein.ShowCheckBox = true;
            this.dtpTimein.ShowUpDown = true;
            this.dtpTimein.Size = new System.Drawing.Size(194, 26);
            this.dtpTimein.TabIndex = 5;
            this.dtpTimein.Value = new System.DateTime(2019, 5, 16, 19, 14, 47, 0);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(3, 11);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(84, 20);
            this.label22.TabIndex = 3;
            this.label22.Text = "Giờ Vào :";
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.txtTenNVCC);
            this.panel24.Controls.Add(this.label20);
            this.panel24.Location = new System.Drawing.Point(101, 17);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(299, 40);
            this.panel24.TabIndex = 13;
            // 
            // txtTenNVCC
            // 
            this.txtTenNVCC.Location = new System.Drawing.Point(87, 8);
            this.txtTenNVCC.Name = "txtTenNVCC";
            this.txtTenNVCC.Size = new System.Drawing.Size(198, 26);
            this.txtTenNVCC.TabIndex = 3;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(3, 12);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(78, 20);
            this.label20.TabIndex = 3;
            this.label20.Text = "Tên NV :";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.panel32);
            this.tabPage8.Controls.Add(this.panel31);
            this.tabPage8.Location = new System.Drawing.Point(4, 29);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.tabPage8.Size = new System.Drawing.Size(1014, 447);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Lương";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.dgvTinhLuong);
            this.panel32.Location = new System.Drawing.Point(3, 144);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(1004, 300);
            this.panel32.TabIndex = 3;
            // 
            // dgvTinhLuong
            // 
            this.dgvTinhLuong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTinhLuong.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20});
            this.dgvTinhLuong.Location = new System.Drawing.Point(3, 3);
            this.dgvTinhLuong.Name = "dgvTinhLuong";
            this.dgvTinhLuong.Size = new System.Drawing.Size(999, 294);
            this.dgvTinhLuong.TabIndex = 0;
            this.dgvTinhLuong.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTinhLuong_CellClick);
            // 
            // Column17
            // 
            this.Column17.DataPropertyName = "MaNV";
            this.Column17.HeaderText = "Mã NV";
            this.Column17.Name = "Column17";
            this.Column17.Width = 200;
            // 
            // Column18
            // 
            this.Column18.DataPropertyName = "TenNV";
            this.Column18.HeaderText = "Tên NV";
            this.Column18.Name = "Column18";
            this.Column18.Width = 250;
            // 
            // Column19
            // 
            this.Column19.DataPropertyName = "SoGioLam";
            this.Column19.HeaderText = "Số Giờ Làm";
            this.Column19.Name = "Column19";
            this.Column19.Width = 250;
            // 
            // Column20
            // 
            this.Column20.DataPropertyName = "Luong";
            this.Column20.HeaderText = "Lương";
            this.Column20.Name = "Column20";
            this.Column20.Width = 250;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.panel35);
            this.panel31.Controls.Add(this.panel34);
            this.panel31.Controls.Add(this.panel33);
            this.panel31.Location = new System.Drawing.Point(5, 8);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(1000, 130);
            this.panel31.TabIndex = 2;
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.btnReStartL);
            this.panel35.Controls.Add(this.btnTinhLuong);
            this.panel35.Controls.Add(this.label31);
            this.panel35.Controls.Add(this.label30);
            this.panel35.Controls.Add(this.Lươn);
            this.panel35.Location = new System.Drawing.Point(778, 0);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(219, 123);
            this.panel35.TabIndex = 2;
            // 
            // btnReStartL
            // 
            this.btnReStartL.Location = new System.Drawing.Point(22, 42);
            this.btnReStartL.Name = "btnReStartL";
            this.btnReStartL.Size = new System.Drawing.Size(84, 51);
            this.btnReStartL.TabIndex = 4;
            this.btnReStartL.Text = "ReStart";
            this.btnReStartL.UseVisualStyleBackColor = true;
            this.btnReStartL.Click += new System.EventHandler(this.btnReStartL_Click);
            // 
            // btnTinhLuong
            // 
            this.btnTinhLuong.Location = new System.Drawing.Point(112, 42);
            this.btnTinhLuong.Name = "btnTinhLuong";
            this.btnTinhLuong.Size = new System.Drawing.Size(84, 51);
            this.btnTinhLuong.TabIndex = 3;
            this.btnTinhLuong.Text = "Tính Lương";
            this.btnTinhLuong.UseVisualStyleBackColor = true;
            this.btnTinhLuong.Click += new System.EventHandler(this.btnTinhLuong_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(3, 103);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(58, 20);
            this.label31.TabIndex = 2;
            this.label31.Text = "14K/H";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(129, 16);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(67, 20);
            this.label30.TabIndex = 1;
            this.label30.Text = "label30";
            // 
            // Lươn
            // 
            this.Lươn.AutoSize = true;
            this.Lươn.Location = new System.Drawing.Point(20, 16);
            this.Lươn.Name = "Lươn";
            this.Lươn.Size = new System.Drawing.Size(59, 20);
            this.Lươn.TabIndex = 0;
            this.Lươn.Text = "Lương";
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.nrdTangCa);
            this.panel34.Controls.Add(this.txtThuong);
            this.panel34.Controls.Add(this.label28);
            this.panel34.Controls.Add(this.label27);
            this.panel34.Location = new System.Drawing.Point(426, 4);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(265, 123);
            this.panel34.TabIndex = 1;
            // 
            // nrdTangCa
            // 
            this.nrdTangCa.Location = new System.Drawing.Point(105, 22);
            this.nrdTangCa.Name = "nrdTangCa";
            this.nrdTangCa.Size = new System.Drawing.Size(144, 26);
            this.nrdTangCa.TabIndex = 4;
            this.nrdTangCa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtThuong
            // 
            this.txtThuong.Location = new System.Drawing.Point(105, 65);
            this.txtThuong.Name = "txtThuong";
            this.txtThuong.Size = new System.Drawing.Size(144, 26);
            this.txtThuong.TabIndex = 3;
            this.txtThuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(13, 71);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(79, 20);
            this.label28.TabIndex = 2;
            this.label28.Text = "Thưởng :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(13, 22);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(86, 20);
            this.label27.TabIndex = 0;
            this.label27.Text = "Tăng Ca :";
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.txtMaNVL);
            this.panel33.Controls.Add(this.txtTenL);
            this.panel33.Controls.Add(this.label26);
            this.panel33.Controls.Add(this.label25);
            this.panel33.Location = new System.Drawing.Point(2, 3);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(362, 127);
            this.panel33.TabIndex = 0;
            // 
            // txtMaNVL
            // 
            this.txtMaNVL.Location = new System.Drawing.Point(127, 66);
            this.txtMaNVL.Name = "txtMaNVL";
            this.txtMaNVL.Size = new System.Drawing.Size(230, 26);
            this.txtMaNVL.TabIndex = 3;
            // 
            // txtTenL
            // 
            this.txtTenL.Location = new System.Drawing.Point(127, 18);
            this.txtTenL.Name = "txtTenL";
            this.txtTenL.Size = new System.Drawing.Size(230, 26);
            this.txtTenL.TabIndex = 2;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(20, 73);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(72, 20);
            this.label26.TabIndex = 1;
            this.label26.Text = "Mã NV :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(20, 25);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(78, 20);
            this.label25.TabIndex = 0;
            this.label25.Text = "Tên NV :";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.reportViewer1);
            this.tabPage9.Location = new System.Drawing.Point(4, 29);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1014, 447);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Báo Cáo";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.DanhThu_ReportBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "QuanLyCaPhe.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(3, 3);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ServerReport.BearerToken = null;
            this.reportViewer1.Size = new System.Drawing.Size(1008, 441);
            this.reportViewer1.TabIndex = 0;
            // 
            // QuanLyCaPheDataSet
            // 
            this.QuanLyCaPheDataSet.DataSetName = "QuanLyCaPheDataSet";
            this.QuanLyCaPheDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // DanhThu_ReportBindingSource
            // 
            this.DanhThu_ReportBindingSource.DataMember = "DanhThu_Report";
            this.DanhThu_ReportBindingSource.DataSource = this.QuanLyCaPheDataSet;
            // 
            // DanhThu_ReportTableAdapter
            // 
            this.DanhThu_ReportTableAdapter.ClearBeforeFill = true;
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 484);
            this.Controls.Add(this.tabControl);
            this.Name = "FormAdmin";
            this.Text = "FormAdmin";
            this.Load += new System.EventHandler(this.FormAdmin_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhThu)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThucAn)).EndInit();
            this.panel4.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel17.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMuc)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBanAn)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTK)).EndInit();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.gbChiTiet.ResumeLayout(false);
            this.gbChiTiet.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChamCong)).EndInit();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTinhLuong)).EndInit();
            this.panel31.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nrdTangCa)).EndInit();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.QuanLyCaPheDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DanhThu_ReportBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.DateTimePicker dtpNgayKetThucHoaDon;
        private System.Windows.Forms.DateTimePicker dtpNgayTaoHoaDon;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvDanhThu;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txtSFname;
        private System.Windows.Forms.Button btnTimkimF;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dgvThucAn;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnXemF;
        private System.Windows.Forms.Button btnSuaF;
        private System.Windows.Forms.Button btnXoaF;
        private System.Windows.Forms.Button btnThemF;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtFID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.ComboBox cmbDanhMucF;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox txtMauKhauTK;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button btnReloadTK;
        private System.Windows.Forms.Button btnReNewTK;
        private System.Windows.Forms.Button btnHuyTK;
        private System.Windows.Forms.Button btnLuuTK;
        private System.Windows.Forms.Button btnXoaTK;
        private System.Windows.Forms.Button btnThemTK;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txtTenTK;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox gbChiTiet;
        private System.Windows.Forms.DateTimePicker dtbNgaySinh;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtbNgayNV;
        private System.Windows.Forms.RadioButton rdbNu;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtTenNV;
        private System.Windows.Forms.TextBox txtHoNV;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dgvNhanVien;
        private System.Windows.Forms.Button btnReloadNV;
        private System.Windows.Forms.Button btnHuyNV;
        private System.Windows.Forms.Button btnLuuNV;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.Button btnLuuF;
        private System.Windows.Forms.Button btnHuyF;
        private System.Windows.Forms.TextBox txtGiaF;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox txtTenDM;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox txtIDDM;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button btnXemDM;
        private System.Windows.Forms.Button btnSuaDM;
        private System.Windows.Forms.Button btnXoaDM;
        private System.Windows.Forms.Button btnThemDM;
        private System.Windows.Forms.DataGridView dgvDanhMuc;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TextBox txtTrangThaiB;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.TextBox txtTenB;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.TextBox txtIDB;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Button btnXemB;
        private System.Windows.Forms.Button btnSuaB;
        private System.Windows.Forms.Button btnXoaB;
        private System.Windows.Forms.Button btnThemB;
        private System.Windows.Forms.DataGridView dgvBanAn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Button btnBoChamCong;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.DateTimePicker dtpTimeOut;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.TextBox txtMaNVCC;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnChamCong;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DataGridView dgvChamCong;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.DateTimePicker dtpTimein;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.TextBox txtTenNVCC;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.DataGridView dgvTinhLuong;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Button btnReStartL;
        private System.Windows.Forms.Button btnTinhLuong;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label Lươn;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.NumericUpDown nrdTangCa;
        private System.Windows.Forms.TextBox txtThuong;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.TextBox txtMaNVL;
        private System.Windows.Forms.TextBox txtTenL;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnLuuDM;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.Button btnLuuB;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txtMaNVTK;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DataGridView dgvTK;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaThucAn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenMonAn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gia;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.Button btnChonAnh;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewImageColumn Anh;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.TabPage tabPage9;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource DanhThu_ReportBindingSource;
        private QuanLyCaPheDataSet QuanLyCaPheDataSet;
        private QuanLyCaPheDataSetTableAdapters.DanhThu_ReportTableAdapter DanhThu_ReportTableAdapter;
    }
}